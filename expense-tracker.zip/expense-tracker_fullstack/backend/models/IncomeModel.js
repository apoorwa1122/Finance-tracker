const mongoose = require('mongoose');

const IncomeSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    amount: {
        type: Number,
        required: true
    },
    category: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true,
        maxlength: 100 // Increase the maximum length as needed
    },
    date: {
        type: Date,
        required: true
    },
    type: {
        type: String,
        required: true
    }
});

module.exports = mongoose.model('Income', IncomeSchema);